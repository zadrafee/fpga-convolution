/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Milad/Downloads/Convolution/Convolution_VHDL/Convolution_VHDL_tb.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;
extern char *STD_TEXTIO;

char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_1242562249_sub_2110339434_1035706684(char *, char *, char *, char *, char *);
int ieee_p_1242562249_sub_2271993008_1035706684(char *, char *, char *);
char *ieee_p_1242562249_sub_2563015576_1035706684(char *, char *, int , int );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_0231030026_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 4008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 4936);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 2448U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3816);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(83, ng0);
    t2 = (t0 + 4936);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 2448U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3816);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_0231030026_2372691052_p_1(char *t0)
{
    char t10[16];
    char t11[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t9;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    int t19;

LAB0:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4824);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(99, ng0);
    t3 = (t0 + 5000);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(101, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t8 = (t2 == (unsigned char)2);
    if (t8 != 0)
        goto LAB5;

LAB7:
LAB6:    xsi_set_current_line(107, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t3 = t1;
    memset(t3, (unsigned char)2, 8U);
    t4 = (t0 + 5192);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(108, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t3 = t1;
    memset(t3, (unsigned char)2, 8U);
    t4 = (t0 + 5256);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(110, ng0);
    t1 = (t0 + 2152U);
    t3 = *((char **)t1);
    t1 = (t0 + 8720U);
    t4 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t10, 128, 10);
    t2 = ieee_p_1242562249_sub_2110339434_1035706684(IEEE_P_1242562249, t3, t1, t4, t10);
    if (t2 != 0)
        goto LAB8;

LAB10:
LAB9:    goto LAB3;

LAB5:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 5000);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(103, ng0);
    t1 = (t0 + 5064);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(104, ng0);
    t1 = xsi_get_transient_memory(10U);
    memset(t1, 0, 10U);
    t3 = t1;
    memset(t3, (unsigned char)2, 10U);
    t4 = (t0 + 5128);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t1, 10U);
    xsi_driver_first_trans_fast(t4);
    goto LAB6;

LAB8:    xsi_set_current_line(112, ng0);
    t5 = (t0 + 2152U);
    t6 = *((char **)t5);
    t5 = (t0 + 8720U);
    t7 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t11, t6, t5, 1);
    t9 = (t11 + 12U);
    t12 = *((unsigned int *)t9);
    t13 = (1U * t12);
    t8 = (10U != t13);
    if (t8 == 1)
        goto LAB11;

LAB12:    t14 = (t0 + 5128);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t7, 10U);
    xsi_driver_first_trans_fast(t14);
    xsi_set_current_line(114, ng0);
    t1 = (t0 + 4064);
    t3 = (t0 + 2896U);
    t4 = (t0 + 3280U);
    std_textio_readline(STD_TEXTIO, t1, t3, t4);
    xsi_set_current_line(115, ng0);
    t1 = (t0 + 4064);
    t3 = (t0 + 3280U);
    t4 = (t0 + 2568U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    std_textio_read10(STD_TEXTIO, t1, t3, t4);
    xsi_set_current_line(116, ng0);
    t1 = (t0 + 2568U);
    t3 = *((char **)t1);
    t19 = *((int *)t3);
    t1 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, t19, 8);
    t4 = (t10 + 12U);
    t12 = *((unsigned int *)t4);
    t12 = (t12 * 1U);
    t2 = (8U != t12);
    if (t2 == 1)
        goto LAB13;

LAB14:    t5 = (t0 + 5192);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t14 = *((char **)t9);
    memcpy(t14, t1, 8U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(118, ng0);
    t1 = (t0 + 4064);
    t3 = (t0 + 3000U);
    t4 = (t0 + 3280U);
    std_textio_readline(STD_TEXTIO, t1, t3, t4);
    xsi_set_current_line(119, ng0);
    t1 = (t0 + 4064);
    t3 = (t0 + 3280U);
    t4 = (t0 + 2568U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    std_textio_read10(STD_TEXTIO, t1, t3, t4);
    xsi_set_current_line(120, ng0);
    t1 = (t0 + 2568U);
    t3 = *((char **)t1);
    t19 = *((int *)t3);
    t1 = ieee_p_1242562249_sub_2563015576_1035706684(IEEE_P_1242562249, t10, t19, 8);
    t4 = (t10 + 12U);
    t12 = *((unsigned int *)t4);
    t12 = (t12 * 1U);
    t2 = (8U != t12);
    if (t2 == 1)
        goto LAB15;

LAB16:    t5 = (t0 + 5256);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t9 = (t7 + 56U);
    t14 = *((char **)t9);
    memcpy(t14, t1, 8U);
    xsi_driver_first_trans_fast(t5);
    goto LAB9;

LAB11:    xsi_size_not_matching(10U, t13, 0);
    goto LAB12;

LAB13:    xsi_size_not_matching(8U, t12, 0);
    goto LAB14;

LAB15:    xsi_size_not_matching(8U, t12, 0);
    goto LAB16;

}

static void work_a_0231030026_2372691052_p_2(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;

LAB0:    xsi_set_current_line(137, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4840);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(139, ng0);
    t3 = (t0 + 1992U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(141, ng0);
    t3 = (t0 + 4312);
    t7 = (t0 + 3352U);
    t8 = (t0 + 1832U);
    t9 = *((char **)t8);
    t8 = (t0 + 8704U);
    t10 = ieee_p_1242562249_sub_2271993008_1035706684(IEEE_P_1242562249, t9, t8);
    std_textio_write5(STD_TEXTIO, t3, t7, t10, (unsigned char)0, 0);
    xsi_set_current_line(142, ng0);
    t1 = (t0 + 4312);
    t3 = (t0 + 3104U);
    t4 = (t0 + 3352U);
    std_textio_writeline(STD_TEXTIO, t1, t3, t4);
    goto LAB6;

}


extern void work_a_0231030026_2372691052_init()
{
	static char *pe[] = {(void *)work_a_0231030026_2372691052_p_0,(void *)work_a_0231030026_2372691052_p_1,(void *)work_a_0231030026_2372691052_p_2};
	xsi_register_didat("work_a_0231030026_2372691052", "isim/Convolution_VHDL_tb_isim_beh.exe.sim/work/a_0231030026_2372691052.didat");
	xsi_register_executes(pe);
}
